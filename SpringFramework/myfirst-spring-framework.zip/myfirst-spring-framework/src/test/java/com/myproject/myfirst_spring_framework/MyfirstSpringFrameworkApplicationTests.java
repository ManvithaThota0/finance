package com.myproject.myfirst_spring_framework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstSpringFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
