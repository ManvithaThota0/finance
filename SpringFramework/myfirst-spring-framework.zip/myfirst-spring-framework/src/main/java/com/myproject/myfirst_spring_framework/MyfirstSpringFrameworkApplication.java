package com.myproject.myfirst_spring_framework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstSpringFrameworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstSpringFrameworkApplication.class, args);
	}

}
